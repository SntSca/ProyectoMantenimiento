package com.esimedia.features.auth.enums;

public enum EstadoToken {
    SIN_CONFIRMAR,
    EXPIRADA,
    REVOCADA,
    UTILIZADA
}